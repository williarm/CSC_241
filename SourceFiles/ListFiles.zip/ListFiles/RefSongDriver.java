package ch06;

import support.Song;
import ch06.lists.RefUnsortedList;

public class RefSongDriver {
	public static void main(String[] args){
		RefUnsortedList songs = new RefUnsortedList();
		Song song1 = new Song("Lucy in the Sky with Diamonds", 221);
		Song song2 = new Song("Being for the Benefit of Mr. Kite!", 200);
		Song song3 = new Song("Good Morning, Good Morning", 180);
		songs.add(song1);
		songs.add(song2);
		songs.add(song3);	
		
		if(song1.equals(song2))
			System.out.println("true");
		else
			System.out.println("false");
		
		System.out.println(songs);
		
		Song foundSong = (Song) songs.get(song1);
		if(foundSong != null)
			System.out.println("Found the song: " + foundSong + "\n");
		else
			System.out.println("Didn't find the song: " + foundSong + "\n");
		
		//Use the iterator to display the items in the list.
		songs.reset();
		
		for(int count = songs.size(); count > 0; count--){
			Song song = (Song) songs.getNext();
			System.out.println(song);
		}
		
		
		//Call reset to satisfy the preconditions of the iterator method: getNext
		songs.reset();
		System.out.println(songs);
		//remove all of the elements in the list using the iterator: currentPos
		for(int count = songs.size(); count > 0; count--){
			songs.remove();
			System.out.println(songs);
		}
		
	}
}


